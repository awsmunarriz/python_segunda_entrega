from setuptools import setup, find_packages

setup(
    name='Segunda-pre-entrega-Munarriz',
    version='0.1',
    description = "Primer paquete distribuido",
    author = "Mariano Munarriz",
    author_email = "mmunarriz@gmail.com",
    packages=find_packages()
)
